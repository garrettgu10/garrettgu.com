#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main() {
	srand(time(NULL));
	int temp = 0;

	FILE* input = fopen("input.txt", "r");
	FILE* output = fopen("output.txt", "w");

	while(1) {
		temp = fgetc(input);

		if(temp == EOF){
			break;
		}

		temp ^= rand() % 255;

		fputc(temp, output);
	}

	fclose(input);
	fclose(output);
}
